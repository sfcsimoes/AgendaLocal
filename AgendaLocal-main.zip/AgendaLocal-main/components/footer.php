<footer class="d-flex justify-content-center align-items-center py-2 border-top bg-light mt-auto">
    <span class="my-1 text-body-secondary">© 2023 <a href="https://github.com/bielmarfran">Gabriel</a>
        e <a href="https://github.com/sfcsimoes">Sergio</a></span>
</footer>