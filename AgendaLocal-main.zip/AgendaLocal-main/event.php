<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Evento</title>
  <link rel="stylesheet" href="./styles/bootstrap.min.css" />
  <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>
  <?php
  if (isset($_GET['id'])) {
    $id = $_GET['id'];
  } else {
    header('Location:index.php');
  }
  ?>
  <div class="d-flex flex-column min-vh-100 mountain">
    <?php require('components/header.php') ?>
    <?php require('helpers/database.php') ?>

    <?php
    $sql1 = 'SELECT 
      e.Id
      , e.Name
      , e.Date
      , e.Location
      , e.Description
      , e.Organization
      , e.Image 
      , e.CategoryId 
      , c.Name as CategoryName
      FROM  `events` e 
    INNER JOIN categories c ON c.Id = e.CategoryId 
      WHERE e.id = :id
      AND e.Active = 1';
    $stmt1 = $dbh->prepare($sql1);
    $stmt1->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt1->execute();
    if($stmt1->rowCount() == 0){
      header('Location:index.php');
    }
    ?>

    <div class="container min-vh-auto py-4 px-3 mx-auto">
      <?php
      if ($stmt1 && $stmt1->rowCount() > 0) {
        $event = $stmt1->fetchObject()
      ?>
        <div class="row mt-1 g-4">
          <h1 class="mt-2 d-md-none" id="eventName"><?= $event->Name ?></h1>
          <div class="col-12 col-md-6">
            <img src="<?= $event->Image ? 'assets/images/' . $event->Image : 'https://placehold.co/700x400' ?>" class="img-fluid" alt="..." id="image" />
          </div>
          <div class="col-12 col-md-6">
            <h1 class="mt-2 d-none d-md-block" id="eventName"><?= $event->Name ?></h1>
            <a class="badge bg-secondary fs-5 text-decoration-none text-white mt-2" href="index.php?category=<?= $event->CategoryId ?>"><?= $event->CategoryName ?></a>
            <div class="mt-2 fs-3">
              Data e Hora
              <div class="d-flex align-items-center mt-2 fs-5">
                <img src="./assets/icons/calendar-check.svg" class="me-3" />
                <?= date_format(date_create($event->Date), 'd/m/Y H:i') ?>
              </div>
            </div>
            <div class="mt-2 fs-3">
              Local
              <div class="d-flex align-items-center mt-2 fs-5">
                <img src="./assets/icons/geo-alt-fill.svg" class="me-3" />
                <?= $event->Location ?>
              </div>
            </div>
          </div>
        </div>
        <div class="mt-2">
          <span class="fs-3">Descricao</span>
          <div class="mt-2 fs-5">
            <?= $event->Description ?>
          </div>
        </div>
        <div class="mt-2">
          <span class="fs-3">Organizador</span>
          <div class="mt-2 fs-5">
            <?= $event->Organization ?>
          </div>
        </div>
        <div class="mt-2">
          <span class="fs-4">Adicione ao seu Calendario</span>
          <div class="mt-2 fs-5">
            <a id="addToCalendar" class="text-decoration-none text-reset" href="https://calendar.google.com/calendar/u/0/r/eventedit?dates=<?= date_format(date_create($event->Date), 'Ymd\THisp') ?>/<?= date_format(date_create($event->Date), 'Ymd\THisp') ?>&ctz=Europe/Lisbon&text=<?= urlencode($event->Name) ?>&location= <?= urlencode($event->Location) ?>&details=<?= urlencode($event->Description) ?>" target="_blank">
              <img src="./assets/icons/googlecalendar.svg" class="me-3" />
              Google
            </a>
          </div>

          <div class="mt-2 fs-5">
            <a id="ics" class="text-decoration-none text-reset" href=" helpers/ics.php?start=<?= date_format(date_create($event->Date), 'Ymd\THisp') ?>&end=<?= date_format(date_create($event->Date), 'Ymd\THisp') ?>&name=<?= urlencode($event->Name) ?>&location=<?= urlencode($event->Location) ?>&description=<?= urlencode($event->Description) ?>">
              <img src="./assets/icons/calendar-check.svg" class="me-3" />
              Calendario (Arquivo ICS)
            </a>
          </div>
        </div>
      <?php
      }
      ?>

    </div>
    <?php require('components/footer.php') ?>
  </div>
  <script src="./js/bootstrap.bundle.min.js"></script>
  <script>
  </script>
</body>

</html>