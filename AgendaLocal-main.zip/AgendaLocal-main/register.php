<html lang="pt-PT">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Registo</title>
  <link rel="stylesheet" href="./styles/bootstrap.min.css" />
</head>

<body>
  <?php
  $error = '';
  if (isset($_POST['username'], $_POST['password'], $_POST['passwordConfirm'])) {
    require('helpers/database.php');
    $sql = 'SELECT * FROM `users` WHERE `Username` = :username';
    $stmt = $dbh->prepare($sql);
    $stmt->bindParam(':username', $_POST['username']);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
      $error = 'Username já associado a uma conta';
    } else {
      $sqlInsert = 'INSERT INTO `users` 
        (
            `Username`
            , `Password`
        ) 
        VALUES 
        (
            :username
            , :password
        )';
      $stmt2 = $dbh->prepare($sqlInsert);
      $password = md5($_POST['password']);
      $stmt2->bindParam(':username', $_POST['username']);
      $stmt2->bindParam(':password', $password);
      $stmt2->execute();


      $LAST_ID = $dbh->lastInsertId();
      if ($LAST_ID > 0) {
        header('Location:login.php');
      }
    }
  }
  ?>
  <div class="d-flex flex-column align-items-center justify-content-center min-vh-100 bg-light">
    <div class="mb-4">
      <a href="index.php" class="navbar-brand">
        <img src="./assets/icons/logo.svg" alt="Logo" style="width: 75px; height: 75px" />
        <span class="align-middle fs-2">AGENDA LOCAL</span>
      </a>
    </div>
    <div class="card col-10 col-md-8 col-lg-4">
      <div class="card-body p-4">
        <div class="d-flex p-4">
          <div class="my-auto">
            <a href="javascript: history.back()"><img src="./assets/icons/arrow-left.svg" style="height: 1.5rem;"></a>
          </div>
          <div class="fs-2 mx-auto">Registo</div>
        </div>
        <?php
        if (strlen($error) > 0) {
        ?>
          <div class="alert alert-danger d-flex" role="alert">
            <img class="flex-shrink-0 me-2" role="img" aria-label="Danger:" src="./assets/icons/exclamation-triangle-fill.svg" />
            <div>
              <?= $error ?>
            </div>
          </div>
        <?php
        }
        ?>
        <form method="POST" name="login" id="registerForm" novalidate>
          <div class="mb-3">
            <label for="eventName" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required />
            <div class="invalid-feedback">Insira um Username valido.</div>
          </div>
          <div class="mb-3">
            <label for="eventName" class="form-label">Senha</label>
            <div class="input-group has-validation">
              <input type="password" class="form-control" id="password" name="password" required />
              <input type="checkbox" class="d-none" id="showPassword" />
              <span class="input-group-text" onclick="show('password','showIcon', 'showPassword')">
                <img id="showIcon" src="./assets/icons/eye-slash.svg" />
              </span>
              <div class="invalid-feedback">Insira uma Senha</div>
            </div>
          </div>
          <div class="mb-3">
            <label for="eventName" class="form-label">Confirme a Senha</label>
            <div class="input-group has-validation">
              <input type="password" class="form-control" id="passwordConfirm" name="passwordConfirm" required />
              <input type="checkbox" class="d-none" id="showPasswordConfirm" />
              <span class="input-group-text" onclick="show('passwordConfirm','showIconConfirm', 'showPasswordConfirm')">
                <img id="showIconConfirm" src="./assets/icons/eye-slash.svg" />
              </span>
              <div class="invalid-feedback">Senhas não são iguais</div>
            </div>
          </div>
          <button type="submit" class="btn btn-secondary mt-3 w-100">
            Criar
          </button>
        </form>
      </div>
    </div>
  </div>
  <script>
    const registerForm = document.getElementById('registerForm');
    const passwordConfirm = document.getElementById('passwordConfirm');
    registerForm.addEventListener("submit", async (event) => {
      const formProps = Object.fromEntries(new FormData(event.target));

      if (formProps.password != formProps.passwordConfirm) {
        passwordConfirm.setCustomValidity("Senhas não são iguais");
        event.preventDefault();
        event.stopPropagation();
      } else {
        passwordConfirm.setCustomValidity("");
      }

      if (!registerForm.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }


      registerForm.classList.add('was-validated');
      registerForm.action = "register.php";
    }, false);

    function show(inputId, iconId, showId) {
      let showIcon = document.querySelector("#" + iconId);
      let password = document.querySelector("#" + inputId);
      let show = document.querySelector("#" + showId);
      show.checked = !show.checked;
      if (show.checked) {
        showIcon.src = "./assets/icons/eye.svg";
        password.type = "text";
      } else {
        showIcon.src = "./assets/icons/eye-slash.svg";
        password.type = "password";
      }
    }
  </script>
</body>

</html>