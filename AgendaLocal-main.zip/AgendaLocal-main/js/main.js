const filterOptions = document.querySelectorAll('.categoryToggle');
Array.from(filterOptions).forEach(btn => {
    btn.addEventListener('click', event => {
        let url = new URL(window.location.href);
        if (btn.checked) {
            if (url.searchParams.has('category')) {
                url.searchParams.set("category", btn.value)
            } else {
                url.searchParams.append("category", btn.value);
            }
        }else{
            url.searchParams.delete("category");
        }
        window.location.href = url;
    });
});

let searchEvent = document.getElementById("searchEvent");
searchEvent.addEventListener('keypress', function (e) {
    let url = new URL(window.location.href);
    if (e.key === 'Enter') {
        if (url.searchParams.has('search')){
            url.searchParams.set("search", searchEvent.value )
        }else{
            url.searchParams.append("search", searchEvent.value);
        }
        window.location.href = url.href;
    }
});

