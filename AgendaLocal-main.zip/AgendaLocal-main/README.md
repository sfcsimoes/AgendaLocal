## Use um ambiente de desenvolvimento como Laragon ou semelhante.

## Crie a base de dados utilizando o script na pasta sql.

## Usuario padrão

    username: web
    password: web
