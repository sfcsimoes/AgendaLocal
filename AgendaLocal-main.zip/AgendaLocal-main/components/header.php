<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
?>
<nav class="navbar bg-light justify-content-evenly">
    <a href="index.php" class="navbar-brand">
        <img src="./assets/icons/logo.svg" alt="Logo" style="width: 65px; height: 65px" />
        <span class="align-middle fs-3">AGENDA LOCAL</span>
    </a>
    <div class="btn-group">
        <button type="button" class="badge rounded-pill border border-1 text-dark bg-white" style="height: 2,5rem;" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="./assets/icons/list.svg" class="align-self-center me-2" alt="Icone Lista" style="width: 28px; height: 28px" />
            <img src="./assets/icons/person-circle.svg" class="align-self-center" alt="Icone Pessoa" style="width: 28px; height: 28px" />
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
            <?php
            if (isset($_SESSION["username"])) {
            ?>
                <li><a class="dropdown-item" href="management.php">Gestão de Eventos</a></li>
            <?php
            } else {
            ?>
                <li><a class="dropdown-item" href="login.php">Login</a></li>
            <?php
            }
            ?>
            <li>
                <hr class="dropdown-divider">
            </li>
            <li><a class="dropdown-item <?= !isset($_SESSION["username"]) ? 'disabled' : '' ?>" href="./helpers/logout.php">Logout</a></li>
        </ul>
    </div>
</nav>