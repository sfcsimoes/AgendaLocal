<!DOCTYPE html>
<html lang="pt-PT">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Agenda Local</title>
  <link rel="stylesheet" href="./styles/bootstrap.min.css" />
  <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>
  <div class="d-flex flex-column min-vh-100 mountain">
    <?php require('components/header.php') ?>
    <?php require('helpers/database.php') ?>



    <?php
    // Busca os Eventos
    $sql1 = 'SELECT 
                e.Id
                , e.Name
                , e.Image 
                FROM  `events` e 
            INNER JOIN categories c ON c.Id = e.CategoryId 
            WHERE e.Active = 1';

    if (isset($_GET['category'])) {
      $sql1 = $sql1 . " AND  e.CategoryId = :categoryId";
    }
    if (isset($_GET['search']) && strlen($_GET['search']) > 0) {
        $sql1 = $sql1 . " AND e.Name LIKE :search OR e.Location LIKE :search";
    }

    $stmt1 = $dbh->prepare($sql1);

    if (isset($_GET['category'])) {
      $stmt1->bindParam(':categoryId', $_GET['category']);
    }

    if (isset($_GET['search']) && strlen($_GET['search']) > 0) {
      $like = "%" . $_GET['search'] . "%";
      $stmt1->bindParam(':search', $like);
    }

    $stmt1->execute();


    $sql2 = 'SELECT * FROM  `categories` WHERE `Active` = 1';
    $stmt2 = $dbh->prepare($sql2);
    $stmt2->execute();

    function setCategory($id)
    {
      if (isset($_GET['category']) && $id == $_GET['category']) {
        echo 'checked';
      }
    }
    ?>
    <div class="container py-4 px-3 mx-auto">
      <div class="input-group mb-3">
        <span class="input-group-text">
          <img src="./assets/icons/search.svg" alt="">
        </span>
        <input type="text" class="form-control" id="searchEvent" value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>" />
      </div>
      <div class="d-flex">
        <?php
        while ($category = $stmt2->fetchObject()) {
          $id = $category->Id;
          $name = $category->Name;
        ?>
          <div class="ms-1">
            <input type="checkbox" class="btn-check categoryToggle" id="btn-<?= $name ?>" name="<?= $name ?>" value="<?= $id ?>" <?= setCategory($id) ?> />
            <label class="btn btn-outline-secondary" for="btn-<?= $name ?>"><?= $name ?></label>
          </div>
        <?php
        }
        ?>
      </div>

      <hr class="border border-secondary border-2 opacity-50" />
      <div class="container" id="cards">
        <?php
        $i = 0;
        // Garante duas imagens por div
        if ($i == 0 || $i % 2 == 0) {
        ?>
          <div class="row mt-1 g-2">
          <?php
        }
        while ($event = $stmt1->fetchObject()) {
          $id = $event->Id;
          $name = $event->Name;
          $image = $event->Image;

          ?>
            <div class="col-12 col-md-6 ">
              <a href="./event.php?id=<?= $id ?>" class="card">
                <img src="assets/images/<?= $image ?>" class="card-img-top" onerror="this.src='https://placehold.co/700x400'" alt="Imagem <?= $name ?>" />
                <div class="card-body">
                  <h5 class="card-title"><?= $name ?></h5>
                </div>
              </a>
            </div>
          <?php
        }
          ?>
          </div>
      </div>
    </div>
    <?php require('components/footer.php') ?>
    <script type="module" src="./js/main.js"></script>
</body>
<script src="./js/bootstrap.bundle.min.js"></script>

</html>