<?php
class ICS
{
    var $start, $end, $name, $description, $location, $data;
    function __construct($start, $end, $name, $description, $location)
    {
        $this->start = $start;
        $this->end = $end;
        $this->name = $name;
        $this->description = $description;
        $this->location = $location;
        $this->data = "BEGIN:VCALENDAR\nVERSION:2.0\nMETHOD:PUBLISH\nBEGIN:VEVENT\nDTSTART:" 
        . date("Ymd\THis\Z", strtotime($this->start)) 
        . "\nDTEND:" . date("Ymd\THis\Z", strtotime($end)) . "\nLOCATION:" 
        . $this->location . "\nTRANSP: OPAQUE\nSEQUENCE:0\nUID:\nDTSTAMP:" 
        . date("Ymd\THis\Z") . "\nSUMMARY:" 
        . $this->name . "\nDESCRIPTION:" 
        . $this->description . "\nPRIORITY:1\nCLASS:PUBLIC\nBEGIN:VALARM\nTRIGGER:-PT10080M\nACTION:DISPLAY\nDESCRIPTION:Reminder\nEND:VALARM\nEND:VEVENT\nEND:VCALENDAR\n";

    }

    function show()
    {

        header("Content-type:text/calendar");
        header('Content-Disposition: attachment; filename="' . $this->name . '.ics"');
        Header('Content-Length: ' . strlen($this->data));
        Header('Connection: close');
        echo $this->data;
    }
}

if (isset($_GET['start'], $_GET['end'], $_GET['name'], $_GET['location'], $_GET['description'])) {
    $event = new ICS($_GET['start'],$_GET['end'], $_GET['name'], $_GET['description'], $_GET['location']);
    $event->show();
}


?>
