<?php
// Start the session
session_start();
if (isset($_SESSION["username"])) {
  header('Location:management.php');
}
?>
<html lang="pt-PT">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="stylesheet" href="./styles/bootstrap.min.css" />
</head>

<body>
  <?php
  $error = '';
  if (!empty($_POST['username']) && !empty($_POST['password'])) {
    require('helpers/database.php');
    $sql = 'SELECT * FROM `users` WHERE `Username` = :username AND `Password` = :password;';
    $stmt = $dbh->prepare($sql);
    $password = md5($_POST['password']);
    $stmt->bindParam(':username', $_POST['username']);
    $stmt->bindParam(':password', $password);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
      $auth = $stmt->fetchObject();
      $_SESSION["username"] = $auth->Username;
      $_SESSION["userId"] = $auth->Id;
      header('Location:management.php');
    } else {
      $error = 'Credenciais inválidas';
    }
  }
  ?>
  <div class="d-flex flex-column align-items-center justify-content-center min-vh-100 bg-light">
    <div class="mb-4">
      <a href="index.php" class="navbar-brand">
        <img src="./assets/icons/logo.svg" alt="Logo" style="width: 75px; height: 75px" />
        <span class="align-middle fs-2">AGENDA LOCAL</span>
      </a>
    </div>
    <div class="card col-10 col-md-8 col-lg-4">
      <div class="card-body p-4">
        <div class="d-flex p-4">
          <div class="my-auto">
            <a href="javascript: history.back()"><img src="./assets/icons/arrow-left.svg" style="height: 1.5rem;"></a>
          </div>
          <div class="fs-2 mx-auto">Bem Vindo</div>
        </div>
        <?php
        if (strlen($error) > 0) {
        ?>
          <div class="alert alert-danger d-flex" role="alert">
            <img class="flex-shrink-0 me-2" role="img" aria-label="Danger:" src="./assets/icons/exclamation-triangle-fill.svg" />
            <div>
              <?= $error ?>
            </div>
          </div>
        <?php
        }
        ?>
        <form method="POST" action="login.php" name="login">
          <div class="mb-3">
            <label for="eventName" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required />
            <div class="invalid-feedback">Insira um Username valido.</div>
          </div>
          <div class="mb-3">
            <label for="eventName" class="form-label">Senha</label>
            <div class="input-group has-validation">
              <input type="password" class="form-control" id="password" name="password" required />
              <span class="input-group-text" onclick="show()">
                <img src="./assets/icons/eye-slash.svg" id="showIcon" />
              </span>
              <div class="invalid-feedback">Insira uma Senha</div>
            </div>
          </div>
          <button type="submit" class="btn btn-secondary mt-3 w-100">
            Login
          </button>
        </form>

        <hr>
        <div class="text-center">
          Não tem uma conta? <a href="register.php">Inscrever-se</a>

        </div>
      </div>
    </div>
  </div>
  <script>
    let showPassword = false;
    let showIcon = document.querySelector("#showIcon");
    let password = document.querySelector("#password");

    function show() {
      showPassword = !showPassword;
      if (showPassword) {
        showIcon.src = "./assets/icons/eye.svg";
        password.type = "text";
      } else {
        showIcon.src = "./assets/icons/eye-slash.svg";
        password.type = "password";
      }
    }
  </script>
</body>

</html>