<?php

$image_file = $_FILES["image"];
$hasImage = false;
if ($_POST["update"] == 'false' || (isset($image_file) && filesize($image_file["tmp_name"]) > 0)) {
    $hasImage = true;

    if (!isset($image_file)) {
        die('No file uploaded.');
    }

    if (filesize($image_file["tmp_name"]) <= 0) {
        die('Uploaded file has no contents.');
    }

    $image_type = exif_imagetype($image_file["tmp_name"]);
    if (!$image_type) {
        die('Uploaded file is not an image.');
    }

    $image_extension = image_type_to_extension($image_type, true);
    $image_name = bin2hex(random_bytes(16)) . $image_extension;

    move_uploaded_file(
        // Temp image location
        $image_file["tmp_name"],
        // New image location
        "../assets/images/" . $image_name
    );
}

require('database.php');
session_start();

if($_POST["active"] == "on") {
    $active = 1;
} else {
    $active = 0;
}
if ($_POST["update"] == 'true') {
    $img = "";

    if ($hasImage) {
        $img =   ",`Image` = :image";
    }
    $sqlUpdate = "UPDATE `events`  SET   
        `Name`= :name
        ,`Date` = :date
        ,`Location` = :location
        ,`CategoryId` = :categoryId
        ,`Description` = :description
        $img
        ,`Organization` = :organization
        ,`Active` = :active
        WHERE id = :id";

    $stmt = $dbh->prepare($sqlUpdate);
   
    if ($hasImage) {
        $stmt->execute(array(
            ':name' => $_POST["name"],
            ':date' => $_POST["date"],
            ':location' => $_POST["location"],
            ':categoryId' => $_POST["category"],
            ':description' => $_POST["description"],
            ':image' =>  $image_name,
            ':organization' => $_POST["owner"],
            ':active' => $active,
            ':id' => $_POST["eventId"]
        ));
    }else{
        $stmt->execute(array(
            ':name' => $_POST["name"],
            ':date' => $_POST["date"],
            ':location' => $_POST["location"],
            ':categoryId' => $_POST["category"],
            ':description' => $_POST["description"],
            ':organization' => $_POST["owner"],
            ':active' => $active,
            ':id' => $_POST["eventId"]
        ));
    }
   
    header('Location: ../management.php');
} else {
    $sql =
        $sql = 'INSERT INTO `events` 
    (
        `Name`
        , `Date`
        , `Location`
        , `CategoryId`
        , `Description`
        , `Image`
        , `Organization`
        , `Active`
        , `CreatedBy`
    ) 
    VALUES 
    (
        :name
        , :date
        , :location
        , :categoryId
        , :description
        , :image
        , :organization
        , :active
        , :createdBy
    )';
    $stmt = $dbh->prepare($sql);
    $stmt->execute(array(
        ':name' => $_POST["name"],
        ':date' => $_POST["date"],
        ':location' => $_POST["location"],
        ':categoryId' => $_POST["category"],
        ':description' => $_POST["description"],
        ':image' => $image_name,
        ':organization' => $_POST["owner"],
        ':active' => $active,
        ':createdBy' => $_SESSION["userId"]
    ));
    $LAST_ID = $dbh->lastInsertId();

    header('Location: ../event.php?id=' . $LAST_ID);
}
