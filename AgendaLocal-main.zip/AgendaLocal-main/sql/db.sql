-- --------------------------------------------------------
-- Anfitrião:                    127.0.0.1
-- Versão do servidor:           8.0.30 - MySQL Community Server - GPL
-- SO do servidor:               Win64
-- HeidiSQL Versão:              12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- A despejar estrutura da base de dados para grupo10
DROP DATABASE IF EXISTS `grupo10`;
CREATE DATABASE IF NOT EXISTS `grupo10` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `grupo10`;

-- A despejar estrutura para tabela grupo10.categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64) NOT NULL,
  `Active` bit(1) NOT NULL DEFAULT b'1',
  `Created` datetime NOT NULL DEFAULT (curdate()),
  `Updated` datetime NOT NULL DEFAULT (curdate()),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- A despejar dados para tabela grupo10.categories: ~4 rows (aproximadamente)
DELETE FROM `categories`;
INSERT INTO `categories` (`Id`, `Name`, `Active`, `Created`, `Updated`) VALUES
	(1, 'Desporto', b'1', '2023-11-22 00:00:00', '2023-11-22 00:00:00'),
	(2, 'Cultural', b'1', '2023-11-22 00:00:00', '2023-11-22 00:00:00'),
	(3, 'Educacional', b'1', '2023-11-22 00:00:00', '2023-11-22 00:00:00'),
	(4, 'Gastronomia', b'1', '2023-11-25 00:00:00', '2023-11-25 00:00:00');

-- A despejar estrutura para tabela grupo10.events
DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64) NOT NULL,
  `Date` datetime NOT NULL,
  `Location` varchar(64) NOT NULL,
  `CategoryId` int NOT NULL,
  `Description` varchar(1024) NOT NULL,
  `Image` varchar(254) NOT NULL,
  `Organization` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Active` tinyint DEFAULT NULL,
  `Created` datetime NOT NULL DEFAULT (curdate()),
  `Updated` datetime NOT NULL DEFAULT (curdate()),
  `CreatedBy` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `CategoryId` (`CategoryId`),
  KEY `FK_Events_Users` (`CreatedBy`),
  CONSTRAINT `events_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `categories` (`Id`),
  CONSTRAINT `FK_Events_Users` FOREIGN KEY (`CreatedBy`) REFERENCES `users` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- A despejar dados para tabela grupo10.events: ~6 rows (aproximadamente)
DELETE FROM `events`;
INSERT INTO `events` (`Id`, `Name`, `Date`, `Location`, `CategoryId`, `Description`, `Image`, `Organization`, `Active`, `Created`, `Updated`, `CreatedBy`) VALUES
	(1, 'Jogo Rugby', '2024-03-01 17:00:00', 'Coimbra', 1, 'Jogo de Rugby emocionante entre equipes locais.', 'sports.jpg', 'Associação de Ruby Lousã', 1, '2023-11-22 00:00:00', '2023-11-22 00:00:00', 1),
	(2, 'Caminhada', '2024-04-12 09:00:00', 'Coimbra', 2, 'Caminhada relaxante pela natureza, explorando belas paisagens.', 'hiking.jpg', 'Câmara Municipal da Lousã', 1, '2023-11-22 00:00:00', '2023-11-22 00:00:00', 1),
	(3, 'Corrida Ciclismo de montanha', '2024-02-15 10:00:00', 'Lousã', 1, 'Desafio de Corrida de Ciclismo de Montanha com trilhas emocionantes.', 'biking.jpg', 'Federação Portuguesa de Ciclismo', 1, '2023-11-22 00:00:00', '2023-11-22 00:00:00', 1),
	(4, 'Queima das Fitas', '2024-05-24 19:00:00', 'Coimbra', 2, 'Participe da emocionante celebração da Queima das Fitas, uma tradição estudantil centenária em Coimbra. O evento marca o fim do ano acadêmico com música ao vivo, desfiles coloridos, e muita animação.', 'ribbons.jpg', 'Associação Académica de Coimbra', 1, '2023-11-22 00:00:00', '2023-11-22 00:00:00', 1),
	(5, 'Exposição de Arte Moderna', '2024-01-25 19:00:00', 'Galeria de Arte Contemporânea', 2, 'Descubra obras inovadoras de artistas locais e internacionais nesta emocionante exposição de arte moderna.', 'art.jpg', 'Associação de Arte Moderna', 1, '2023-11-25 00:00:00', '2023-11-25 00:00:00', 1),
	(6, 'Festival Gastronômico', '2024-02-27 11:05:00', 'Miranda do Corvo', 4, 'Explore uma variedade de sabores deliciosos neste festival gastronômico, apresentando pratos exclusivos de chefs renomados.', 'food.jpg', 'Autarquia Miranda do Corvo', 1, '2023-11-25 00:00:00', '2023-11-25 00:00:00', 1);

-- A despejar estrutura para tabela grupo10.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(124) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Password` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Created` datetime NOT NULL DEFAULT (curdate()),
  `Updated` datetime NOT NULL DEFAULT (curdate()),
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- A despejar dados para tabela grupo10.users: ~1 rows (aproximadamente)
DELETE FROM `users`;
INSERT INTO `users` (`Id`, `Username`, `Password`, `Created`, `Updated`) VALUES
	(1, 'web', '2567a5ec9705eb7ac2c984033e06189d', '2023-11-23 00:00:00', '2023-11-23 00:00:00');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;


-- Create a new user
CREATE USER IF NOT EXISTS 'web'@'localhost' IDENTIFIED BY 'web';

-- Grant permissions to the user
GRANT SELECT, INSERT, UPDATE ON grupo10.* TO 'web'@'localhost';

-- Flush privileges to apply changes
FLUSH PRIVILEGES;
