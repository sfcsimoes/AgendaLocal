<?php
function addEdit($event, $categories)
{
    $id = $event->Id;
    $name = $event->Name;
    $date = $event->Date;
    $description = $event->Description;
    $location = $event->Location;
    $organization = $event->Organization;
    $active = $event->Active;
    $image = $event->Image;
    $categoryId = $event->CategoryId;
?>
    <button type="button" class="btn btn-secondary ms-auto" data-bs-toggle="modal" id="editEventButton<?= $id ?>" data-bs-target=" #editEvent<?= $id ?>">
        Editar
    </button>
    <div class="modal modal-lg fade" id="editEvent<?= $id ?>" tabindex="-1" aria-labelledby="editEventLabel<?= $id ?>" aria-hidden=" true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="editEventLabel<?= $id ?>">Evento</h1>
                    <button type=" button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- FORM -->
                    <form id="editEventForm<?= $id ?>" method="POST" enctype="multipart/form-data" class="editEvent mb-0" novalidate>
                        <input type="hidden" id="eventId" name="eventId" value="<?= showIfSet($id) ?>" />
                        <input type="hidden" name="update" value="true" />
                        <div class="row">

                            <div class="mb-3">
                                <label for=" eventName" class="form-label">Nome</label>
                                <input type="text" class="form-control" id="eventName" name="name" required value="<?= showIfSet($name) ?>" />
                            </div>

                            <div class="mb-3 col-md-6">
                                <label for="eventDate" class="form-label">Data</label>
                                <input type="datetime-local" class="form-control" id="eventDate" name="date" value="<?= showIfSet($date) ?>" required />
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="eventLocation" class="form-label">Local</label>
                                <input type="text" class="form-control" id="eventLocation" name="location" value="<?= showIfSet($location) ?>" required />
                            </div>

                            <div class="mb-3">
                                <label class="form-check-label" for="active">Ativo</label>
                                <div class="form-check form-switch mt-2">
                                    <input class="form-check-input" type="checkbox" role="switch" name="active" id="active" style="width: 2.5rem; height: 1.25rem;" <?= $active == 1 ? 'checked' : '' ?>>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="eventCategory" class="form-label">Categorias</label>
                                <select id="eventCategory" class="form-select" name="category" required>
                                    <option disabled value="">
                                        Selecione uma Categoria...
                                    </option>
                                    <?php
                                    foreach ($categories as $category) {
                                    ?>
                                        <option value="<?= $category->Id ?>" <?= $categoryId == $category->Id ? 'selected' : '' ?>><?= $category->Name ?></option>
                                    <?php
                                    }
                                    ?>

                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="eventDescription">Descrição</label>
                                <textarea id="eventDescription" class="form-control" name="description" style="max-height: 12rem;" required><?= showIfSet($description) ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="eventOwner" class="form-label">Organizador</label>
                                <input type="text" class="form-control" id="eventOwner" name="owner" value="<?= showIfSet($organization) ?>" required />
                            </div>

                            <div>
                                <figure class=" figure" type="button" onclick="openFile(<?= $id ?>)">
                                    <img src="assets/images/<?= isset($image) ?  $image : 'https://placehold.co/320x180'  ?>" class="img-fluid rounded" style="width: 240px; height: 135px" id="image<?= $id ?>" />
                                    <figcaption class="figure-caption">Selecione o arquivo</figcaption>
                                </figure>
                                <input type="file" name="image" accept="image/*" class="d-none" id="inputFIle<?= $id ?>" onchange="inputFile(event, <?= $id ?>)" />
                            </div>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Fechar
                    </button>
                    <button type="submit" class="btn btn-primary" form="editEventForm<?= $id ?>">
                        Editar
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php
}
?>
<script>

</script>