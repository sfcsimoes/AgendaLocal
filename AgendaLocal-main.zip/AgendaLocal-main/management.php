<?php
// Start the session
session_start();
if (!isset($_SESSION["username"])) {
    header('Location:login.php');
}
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão Eventos</title>
    <link rel="stylesheet" href="./styles/bootstrap.min.css" />
    <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>
    <?php
    function showIfSet($value)
    {
        if (isset($value)) {
            echo $value;
        }
    }
    require('helpers/database.php');
    $sql = 'SELECT 
                e.Id
                , e.Name
                , e.Image
                , e.Date
                , e.Location
                , e.Description
                , e.Organization
                , e.Active
                , c.Id as CategoryId
                FROM  `events` e
            INNER JOIN categories c ON c.Id = e.CategoryId
                WHERE e.CreatedBy = :id';
    $stmt = $dbh->prepare($sql);
    $stmt->bindParam(':id', $_SESSION["userId"], PDO::PARAM_INT);
    $stmt->execute();

    $sql2 = 'SELECT * FROM  `categories` WHERE `Active` = 1';
    $stmt2 = $dbh->prepare($sql2);
    $stmt2->execute();
    $categories = [];
    while ($category = $stmt2->fetchObject()) {
        array_push($categories, $category);
    }
    // print_r($array);
    require('components/eventEdit.php');
    ?>
    <div class="d-flex flex-column min-vh-100 mountain">
        <?php require('components/header.php') ?>
        <div class="container-lg">
            <div class="card my-4">
                <div class="card-body">
                    <div class="d-flex">
                        <h2 class="card-title">Eventos</h2>
                        <button type="button" class="btn btn-secondary ms-auto" data-bs-toggle="modal" id="addEventButton" data-bs-target="#addEvent">
                            Novo Evento
                        </button>
                    </div>

                    <div class="table-responsive mt-4">
                        <table class="table align-middle table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nome</th>
                                    <th scope="col">Data</th>
                                    <th scope="col">Ativo</th>
                                    <th scope="col">Descrição</th>
                                    <th scope="col">Organização</th>
                                    <th scope="col">Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($event = $stmt->fetchObject()) {
                                    $id = $event->Id;
                                    $name = $event->Name;
                                    $date = $event->Date;
                                    $description = $event->Description;
                                    $location = $event->Location;
                                    $organization = $event->Organization;
                                    $active = $event->Active;
                                    $image = $event->Image;

                                ?>
                                    <tr>
                                        <th scope="row"><?= $id ?></th>
                                        <td><?= $name ?></td>
                                        <td><?= date_format(date_create($date), 'd/m/Y H:i') ?></td>
                                        <td class="<?= $active  == 0 ? 'text-danger' : '' ?>"><?= $active ? 'Sim' : 'Não' ?></td>
                                        <td class="text-truncate" style="max-width: 150px;"><?= $description ?></td>
                                        <td><?= $organization ?></td>
                                        <td> <?php addEdit($event, $categories) ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php require('components/footer.php') ?>
        <div class="modal modal-xl fade" id="addEvent" tabindex="-1" aria-labelledby="addEventLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="addEventLabel">Evento</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- FORM -->
                        <form id="addEventForm" method="POST" enctype="multipart/form-data" novalidate>
                            <input type="text" class="d-none" name="update" value="false" />
                            <div class="row">
                                <div class="mb-3">
                                    <label for="eventName" class="form-label">Nome</label>
                                    <input type="text" class="form-control" id="eventName" name="name" required />
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label for="eventDate" class="form-label">Data</label>
                                    <input type="datetime-local" class="form-control" id="eventDate" name="date" required />
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label for="eventLocation" class="form-label">Local</label>
                                    <input type="text" class="form-control" id="eventLocation" name="location" required />
                                </div>

                                <div class="mb-3">
                                <label class="form-check-label" for="active">Ativo</label>
                                    <div class="form-check form-switch mt-2">
                                        <input class="form-check-input" type="checkbox" role="switch" name="active" id="active" style="width: 2.5rem; height: 1.25rem;" checked>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="eventCategory" class="form-label">Categorias</label>
                                    <select id="eventCategory" class="form-select" name="category" required>
                                        <option selected disabled value="">
                                            Selecione uma Categoria...
                                        </option>
                                        <?php
                                        foreach ($categories as $category) {
                                        ?>
                                            <option value="<?= $category->Id ?>"><?= $category->Name ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="eventDescription">Descrição</label>
                                    <textarea id="eventDescription" class="form-control" name="description" style="max-height: 12rem;" required></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="eventOwner" class="form-label">Organizador</label>
                                    <input type="text" class="form-control" id="eventOwner" name="owner" required />
                                </div>

                                <div>
                                    <figure class=" figure" type="button" onclick="openFile(0)">
                                        <img src="./assets/icons/image.svg" class="img-fluid rounded" style="height: 8rem;" id="image0" />
                                        <figcaption class="figure-caption">Selecione o arquivo</figcaption>
                                    </figure>
                                    <input type="file" name="image" accept="image/*" class="d-none" id="inputFIle0" onchange="inputFile(event, 0)" required />
                                    <div class="invalid-feedback">
                                        <div class="alert alert-danger d-flex" role="alert">
                                            <img class="flex-shrink-0 me-2" role="img" aria-label="Danger:" src="./assets/icons/exclamation-triangle-fill.svg" />
                                            <div>
                                                O evento deve ter uma imagem.
                                            </div>
                                        </div>
                                    </div>
                                </div>


                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Fechar
                        </button>
                        <button type="submit" class="btn btn-primary" form="addEventForm">
                            Adicionar
                        </button>
                    </div>
                </div>
            </div>
        </div>
</body>
<script src="./js/bootstrap.bundle.min.js"></script>
<script>
    function setIds(formId) {
        // const addEventModal = new bootstrap.Modal('#' + modalId);
        const addForm = document.getElementById(formId);
        addForm.addEventListener("submit", async (event) => {
            if (!addForm.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }

            addForm.classList.add('was-validated');
            addForm.action = "./helpers/upload.php";
        }, false);

    }
    setIds('addEventForm');

    const editForms = document.querySelectorAll('.editEvent');
    Array.from(editForms).forEach(form => {
        setIds(form.id);
    });

    function inputFile(e, id) {
        const files = e.target.files || e.dataTransfer.files;
        const file = files[0];
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            if (typeof reader.result == 'string') {
                document.getElementById("image" + id).src = "data:image/jpeg;base64," + reader.result?.split(',')[1];
            }
        };
    }

    function openFile(id) {
        document.getElementById("inputFIle" + id).click();
    }
</script>


</html>